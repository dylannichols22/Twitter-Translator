(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
const MESSAGE_TYPES = {
  SCRAPE_PAGE: "SCRAPE_PAGE",
  OPEN_TRANSLATE_PAGE: "OPEN_TRANSLATE_PAGE",
  GET_SETTINGS: "GET_SETTINGS",
  SAVE_SETTINGS: "SAVE_SETTINGS",
  GET_COST_STATS: "GET_COST_STATS",
  GET_USAGE_STATS: "GET_USAGE_STATS",
  RECORD_USAGE: "RECORD_USAGE",
  GET_CACHED_TRANSLATION: "GET_CACHED_TRANSLATION",
  CACHE_TRANSLATION: "CACHE_TRANSLATION",
  SCRAPE_MORE: "SCRAPE_MORE",
  SMOKE_PING: "SMOKE_PING",
  TOGGLE_PANEL: "TOGGLE_PANEL",
  GET_CONTEXT_TWEET_URL: "GET_CONTEXT_TWEET_URL",
  SAVE_ITEM: "SAVE_ITEM",
  GET_SAVED_ITEMS: "GET_SAVED_ITEMS",
  DELETE_SAVED_ITEM: "DELETE_SAVED_ITEM",
  EXPORT_SAVED_ITEMS: "EXPORT_SAVED_ITEMS",
  IS_ITEM_SAVED: "IS_ITEM_SAVED"
};
export {
  MESSAGE_TYPES as M
};
