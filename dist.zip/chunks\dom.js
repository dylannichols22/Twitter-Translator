function clearElement(element) {
  while (element.firstChild) {
    element.removeChild(element.firstChild);
  }
}
function setText(element, text) {
  element.textContent = text;
}
export {
  clearElement as c,
  setText as s
};
