import { M as MESSAGE_TYPES } from "./messages.js";
const TWITTER_HOSTS = ["twitter.com", "x.com"];
const STATUS_PATH_REGEX = /^\/[^/]+\/status\/(\d+)/;
const TWEET_ID_ATTRIBUTES = ["data-tweet-id", "data-item-id", "data-id", "id"];
const TWITTER_SELECTORS = {
  postContainer: 'article[data-testid="tweet"], div[data-testid="tweet"]',
  postText: '[data-testid="tweetText"]',
  authorName: '[data-testid="User-Name"]',
  timestamp: "time",
  replyButton: '[data-testid="reply"]',
  showRepliesButton: '[data-testid="showMoreReplies"],[data-testid="showReplies"]',
  mainColumn: 'main[role="main"]',
  cellContainer: '[data-testid="cellInnerDiv"]'
};
class TwitterPlatform {
  name = "twitter";
  hosts = TWITTER_HOSTS;
  selectors = TWITTER_SELECTORS;
  // ============================================================
  // URL Handling Methods
  // ============================================================
  isValidUrl(url) {
    try {
      const parsed = new URL(url);
      return TWITTER_HOSTS.some(
        (host) => parsed.hostname === host || parsed.hostname.endsWith(`.${host}`)
      );
    } catch {
      return false;
    }
  }
  isThreadUrl(url) {
    try {
      const parsed = new URL(url);
      const isTwitterHost = TWITTER_HOSTS.some((host) => parsed.hostname.endsWith(host));
      if (!isTwitterHost) return false;
      return STATUS_PATH_REGEX.test(parsed.pathname);
    } catch {
      return false;
    }
  }
  extractPostId(url) {
    try {
      const parsed = new URL(url);
      const match = parsed.pathname.match(STATUS_PATH_REGEX);
      return match ? match[1] : null;
    } catch {
      return null;
    }
  }
  normalizeUrl(url) {
    try {
      const parsed = new URL(url);
      const normalizedHost = parsed.hostname.replace(/(^|\.)x\.com$/, "$1twitter.com");
      return `https://${normalizedHost}${parsed.pathname}`;
    } catch {
      return url;
    }
  }
  // ============================================================
  // Element Methods
  // ============================================================
  extractPostIdFromElement(element) {
    for (const attr of TWEET_ID_ATTRIBUTES) {
      const value = element.getAttribute(attr);
      if (!value) continue;
      const match = value.match(/(\d{5,})/);
      if (match) return match[1];
    }
    const link = this.findPrimaryPostLink(element);
    if (link) {
      const href = link.getAttribute("href") ?? "";
      const match = href.match(/\/status\/(\d+)/);
      if (match) return match[1];
    }
    const statusLink = element.querySelector('a[href*="/status/"]');
    if (statusLink) {
      const href = statusLink.getAttribute("href") ?? "";
      const match = href.match(/\/status\/(\d+)/);
      if (match) return match[1];
    }
    return null;
  }
  hasReplies(element) {
    const replyButton = element.querySelector(this.selectors.replyButton);
    if (!replyButton) return void 0;
    const label = replyButton.getAttribute("aria-label") ?? replyButton.textContent ?? "";
    const match = label.match(/(\d+)/);
    if (match) {
      return Number.parseInt(match[1], 10) > 0;
    }
    return void 0;
  }
  isInlineReply(element) {
    const hasShowReplies = (el) => {
      if (!el) return false;
      const hasTestId = !!el.querySelector(this.selectors.showRepliesButton);
      if (hasTestId) return true;
      const text = el.textContent?.toLowerCase() ?? "";
      return text.includes("show replies") || text.includes("show more replies");
    };
    const cell = element.closest(this.selectors.cellContainer);
    if (hasShowReplies(cell?.previousElementSibling ?? null)) {
      return true;
    }
    if (hasShowReplies(element.previousElementSibling)) {
      return true;
    }
    return false;
  }
  findPrimaryPostLink(element) {
    const timeLinks = Array.from(element.querySelectorAll("time")).map((timeEl) => timeEl.closest('a[href*="/status/"]')).filter((link) => !!link);
    for (const link of timeLinks) {
      if (link.closest('[data-testid="tweet"]') === element) {
        return link;
      }
    }
    const links = Array.from(element.querySelectorAll('a[href*="/status/"]')).filter((link) => link instanceof HTMLAnchorElement).filter((link) => link.closest('[data-testid="tweet"]') === element);
    return links[0] ?? null;
  }
  getPostUrl(element) {
    const link = this.findPrimaryPostLink(element);
    const href = link?.getAttribute("href") ?? "";
    if (!href) return void 0;
    if (href.startsWith("http")) return href;
    return `${window.location.origin}${href}`;
  }
}
const twitterPlatform = new TwitterPlatform();
function isTwitterUrl(url) {
  return twitterPlatform.isValidUrl(url);
}
function formatCost(cost) {
  return `$${cost.toFixed(2)}`;
}
class PopupController {
  translateBtn;
  togglePanelBtn;
  viewSavedBtn;
  settingsBtn;
  saveSettingsBtn;
  backBtn;
  mainView;
  settingsView;
  apiKeyInput;
  commentLimitInput;
  costThisWeek;
  costThisMonth;
  costAllTime;
  statusMessage;
  constructor() {
    this.translateBtn = document.getElementById("translate-btn");
    this.togglePanelBtn = document.getElementById("toggle-panel-btn");
    this.viewSavedBtn = document.getElementById("view-saved-btn");
    this.settingsBtn = document.getElementById("settings-btn");
    this.saveSettingsBtn = document.getElementById("save-settings-btn");
    this.backBtn = document.getElementById("back-btn");
    this.mainView = document.getElementById("main-view");
    this.settingsView = document.getElementById("settings-view");
    this.apiKeyInput = document.getElementById("api-key-input");
    this.commentLimitInput = document.getElementById("comment-limit-input");
    this.costThisWeek = document.getElementById("cost-this-week");
    this.costThisMonth = document.getElementById("cost-this-month");
    this.costAllTime = document.getElementById("cost-all-time");
    this.statusMessage = document.getElementById("status-message");
    this.bindEvents();
    void this.updatePanelToggleVisibility();
    void this.applyAndroidLayout();
  }
  bindEvents() {
    this.translateBtn?.addEventListener("click", () => this.translateCurrentPage());
    this.togglePanelBtn?.addEventListener("click", () => this.togglePanel());
    this.viewSavedBtn?.addEventListener("click", () => this.openSavedPage());
    this.settingsBtn?.addEventListener("click", () => this.showSettings());
    this.saveSettingsBtn?.addEventListener("click", () => this.saveSettings());
    this.backBtn?.addEventListener("click", () => this.showMain());
  }
  async openSavedPage() {
    await browser.tabs.create({
      url: browser.runtime.getURL("saved.html")
    });
    window.close();
  }
  async updatePanelToggleVisibility() {
    if (!this.togglePanelBtn) {
      return;
    }
    try {
      const tabs = await browser.tabs.query({ active: true, currentWindow: true });
      const url = tabs[0]?.url ?? "";
      const isTwitter = isTwitterUrl(url);
      this.togglePanelBtn.classList.toggle("hidden", !isTwitter);
    } catch (error) {
      console.error("Failed to determine active tab:", error);
      this.togglePanelBtn.classList.add("hidden");
    }
  }
  async applyAndroidLayout() {
    if (!this.togglePanelBtn) {
      return;
    }
    try {
      const platform = await browser.runtime.getPlatformInfo?.();
      if (platform?.os === "android") {
        this.togglePanelBtn.classList.add("hidden");
      }
    } catch (error) {
      console.error("Failed to detect platform:", error);
    }
  }
  async loadSettings() {
    try {
      const settings = await browser.runtime.sendMessage({
        type: MESSAGE_TYPES.GET_SETTINGS
      });
      if (this.apiKeyInput) {
        this.apiKeyInput.value = settings.apiKey || "";
      }
      if (this.commentLimitInput) {
        this.commentLimitInput.value = String(settings.commentLimit || 10);
      }
    } catch (error) {
      console.error("Failed to load settings:", error);
    }
  }
  async loadCostStats() {
    try {
      const stats = await browser.runtime.sendMessage({
        type: MESSAGE_TYPES.GET_COST_STATS
      });
      const thisWeek = typeof stats?.thisWeek === "number" ? stats.thisWeek : 0;
      const thisMonth = typeof stats?.thisMonth === "number" ? stats.thisMonth : 0;
      const allTime = typeof stats?.allTime === "number" ? stats.allTime : 0;
      if (this.costThisWeek) {
        this.costThisWeek.textContent = formatCost(thisWeek);
      }
      if (this.costThisMonth) {
        this.costThisMonth.textContent = formatCost(thisMonth);
      }
      if (this.costAllTime) {
        this.costAllTime.textContent = formatCost(allTime);
      }
    } catch (error) {
      console.error("Failed to load cost stats:", error);
    }
  }
  async saveSettings() {
    try {
      const apiKey = this.apiKeyInput?.value || "";
      const parsed = Number.parseInt(this.commentLimitInput?.value || "10", 10);
      if (!Number.isFinite(parsed) || parsed <= 0) {
        this.showStatus("Comment limit must be a positive number");
        if (this.commentLimitInput) {
          this.commentLimitInput.value = "10";
        }
        return;
      }
      const commentLimit = parsed;
      await browser.runtime.sendMessage({
        type: MESSAGE_TYPES.SAVE_SETTINGS,
        data: { apiKey, commentLimit }
      });
      this.showStatus("Settings saved!");
    } catch (error) {
      console.error("Failed to save settings:", error);
      this.showStatus("Failed to save settings");
    }
  }
  async translateCurrentPage() {
    try {
      const tabs = await browser.tabs.query({ active: true, currentWindow: true });
      const tab = tabs[0];
      if (!tab?.id) {
        this.showStatus("No active tab found");
        return;
      }
      const response = await browser.tabs.sendMessage(tab.id, {
        type: MESSAGE_TYPES.SCRAPE_PAGE
      });
      if (!response?.success || !response.tweets) {
        this.showStatus(response?.error || "Failed to scrape page");
        return;
      }
      await browser.runtime.sendMessage({
        type: MESSAGE_TYPES.OPEN_TRANSLATE_PAGE,
        data: {
          tweets: response.tweets,
          url: response.url || tab.url || "",
          sourceTabId: tab.id
        }
      });
      window.close();
    } catch (error) {
      console.error("Failed to translate:", error);
      this.showStatus("Failed to start translation");
    }
  }
  async togglePanel() {
    try {
      const tabs = await browser.tabs.query({ active: true, currentWindow: true });
      const tab = tabs[0];
      if (!tab?.id) {
        this.showStatus("No active tab found");
        return;
      }
      if (!isTwitterUrl(tab.url || "")) {
        this.showStatus("Open Twitter to toggle the panel");
        return;
      }
      await browser.tabs.sendMessage(tab.id, {
        type: MESSAGE_TYPES.TOGGLE_PANEL
      });
      window.close();
    } catch (error) {
      console.error("Failed to toggle panel:", error);
      this.showStatus("Failed to toggle panel");
    }
  }
  showSettings() {
    this.mainView?.classList.add("hidden");
    this.settingsView?.classList.remove("hidden");
    this.loadSettings();
    this.loadCostStats();
  }
  showMain() {
    this.settingsView?.classList.add("hidden");
    this.mainView?.classList.remove("hidden");
  }
  showStatus(message) {
    if (this.statusMessage) {
      this.statusMessage.textContent = message;
      setTimeout(() => {
        if (this.statusMessage) {
          this.statusMessage.textContent = "";
        }
      }, 3e3);
    }
  }
}
if (typeof document !== "undefined" && document.readyState !== "loading") {
  new PopupController();
} else if (typeof document !== "undefined") {
  document.addEventListener("DOMContentLoaded", () => new PopupController());
}
export {
  formatCost as f
};
